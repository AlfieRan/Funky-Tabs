# FunkyTabs
FunkyTabs is a Chrome extension that replaces your New Tab page with a FunkyTab, as of the current version this includes a photo of Mark Zuckerberg, the time, the date and a notepad for you to use.

The original github repo is from Lucid and it uses the notepad, date and light/dark mode switching functuality from this. However any other part of the extension has been added by Alfie Ranstead and is Unique to FunkyTabs.


# Lucid
Lucid is a Chrome Extension that replaces your New Tab page with a notepad. It
also tells you what day it is. It uses your location to determine whether it
should have a dark background or a light one, based on daylight hours.
