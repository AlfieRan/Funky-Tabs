# Lucid

Lucid is a Chrome Extension that replaces your New Tab page with a notepad. It
also tells you what day it is. It uses your location to determine whether it
should have a dark background or a light one, based on daylight hours.
